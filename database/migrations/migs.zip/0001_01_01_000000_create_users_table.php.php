<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->unique();
            $table->string('password');
            $table->string('status')->default('Pending');
            $table->timestamps();
            $table->timestamp('email_verified_at')->nullable();
            $table->rememberToken();
            $table->bigInteger('phone2')->nullable();
            $table->bigInteger('phone')->nullable();
            $table->string('o_code')->nullable();
            $table->string('device_name')->nullable();
            $table->string('device_id')->nullable();
            $table->string('other_name')->nullable();
            $table->string('gender')->nullable();
            $table->bigInteger('employee_id')->nullable();
            $table->bigInteger('assignment_id')->nullable();
            $table->bigInteger('r_id')->nullable();
            $table->string('r_role')->nullable();
            $table->string('r_phone')->nullable();
            $table->timestamp('last_seen_at')->nullable();
            $table->string('profile_photo')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};
